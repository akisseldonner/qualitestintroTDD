/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package introqualitesttdd;

import java.util.ArrayList;

/**
 *
 * @author Aluno
 */
public class Fatura {
    private float valor;
    
    //datapg

    /**
     * @return the valor
     */
    public float getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(float valor) {
        this.valor = valor;
    }
   
    
    
}
